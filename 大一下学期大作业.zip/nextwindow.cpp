#include "nextwindow.h"
#include <QPushButton>
#include <QTimer>
nextwindow::nextwindow(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(1000,700);

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/color.mp3"));
    player->setVolume(30);
    player->play();

    QPushButton * settw1 = new QPushButton(this);
    settw1->setFixedSize(30,30);
    settw1->setStyleSheet("QPushButton{background:white;border: 3px groove gray;border-radius:8px;border-style:outset}"
                     "QPushButton:hover{background-color:white;}"
                     "QPushButton:pressed{background-color:rgb(85, 170, 255); border-style:inset;}");
    settw1->move(760,230);

    connect(settw1,&QPushButton::clicked,this,&nextwindow::setTower1);

    QPushButton * settw2 = new QPushButton(this);
    settw2->setFixedSize(30,30);
    settw2->setStyleSheet("QPushButton{background:white;border: 3px groove gray;border-radius:8px;border-style:outset}"
                     "QPushButton:hover{background-color:white;}"
                     "QPushButton:pressed{background-color:rgb(85, 170, 255); border-style:inset;}");
    settw2->move(540,450);

    connect(settw2,&QPushButton::clicked,this,&nextwindow::setTower2);

    QPushButton * settw3 = new QPushButton(this);
    settw3->setFixedSize(30,30);
    settw3->setStyleSheet("QPushButton{background:white;border: 3px groove gray;border-radius:8px;border-style:outset}"
                     "QPushButton:hover{background-color:white;}"
                     "QPushButton:pressed{background-color:rgb(85, 170, 255); border-style:inset;}");
    settw3->move(300,230);

    connect(settw3,&QPushButton::clicked,this,&nextwindow::setTower3);

    QPushButton * setemy = new QPushButton(this);
    setemy->setFixedSize(30,30);
    setemy->setStyleSheet("QPushButton{background:red;border: 3px groove gray;border-radius:8px;border-style:outset}"
                     "QPushButton:hover{background-color:white;}"
                     "QPushButton:pressed{background-color:rgb(85, 170, 255); border-style:inset;}");
    setemy->move(800,600);

    connect(setemy,&QPushButton::clicked,this,&nextwindow::setenemy);

    QPushButton * setemy1 = new QPushButton(this);
    setemy1->setFixedSize(30,30);
    setemy1->setStyleSheet("QPushButton{background:green;border: 3px groove gray;border-radius:8px;border-style:outset}"
                     "QPushButton:hover{background-color:white;}"
                     "QPushButton:pressed{background-color:rgb(85, 170, 255); border-style:inset;}");
    setemy1->move(850,600);

    connect(setemy1,&QPushButton::clicked,this,&nextwindow::setenemy1);



    QTimer * timer = new QTimer(this);
    connect(timer,&QTimer::timeout,this,&nextwindow::upd);
    timer->start(10);

}

void nextwindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.setPen(QPen(Qt::black,5));
    painter.drawLine(QPoint(0,270),QPoint(1000,270));
    painter.drawLine(QPoint(0,430),QPoint(1000,430));
    QFont font;
        font.setFamily("Microsoft YaHei");
        font.setPointSize(13);
        painter.setFont(font);
    painter.drawText(QPoint(20,350),"destination");
    painter.setPen(QPen(Qt::red,2));
    painter.drawRect(0,320,180,40);
    painter.drawText(QPoint(20,30),"your gold: ");

    foreach(tower * t,towerlist)
        t->draw(&painter);
    foreach(enemy * en,enemylist)
        en->drawenemy(&painter);
}

void nextwindow::setenemy(){
    enemy * en = new enemy(":/enemy.png",QPoint(1000,350));
    enemylist.push_back(en);
    en->move();
    update();
}
void nextwindow::setenemy1(){
    enemy * en = new enemy(":/enemy1.png",QPoint(1000,350));
    enemylist.push_back(en);
    en->move();
    update();
}
void nextwindow::setTower1(){
    tower * t = new tower(QPoint(800,130),":/tower.png");
    towerlist.push_back(t);
    update();
}
void nextwindow::setTower2(){
    tower * t = new tower(QPoint(530,330),":/tower2.png");
    towerlist.push_back(t);
    update();
}
void nextwindow::setTower3(){
    tower * t = new tower(QPoint(320,130),":/tower3.png");
    towerlist.push_back(t);
    update();
}

void nextwindow::upd(){
    update();
}

