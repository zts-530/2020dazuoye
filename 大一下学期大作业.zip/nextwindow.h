#ifndef NEXTWINDOW_H
#define NEXTWINDOW_H

#include <QMainWindow>
#include <QPaintEvent>
#include <QPainter>
#include "tower.h"
#include <QList>
#include "enemy.h"
#include <QMediaPlayer>
#include "towerbase.h"
class nextwindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit nextwindow(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void setTower1();
    void setTower2();
    void setTower3();
    void setenemy();
    void setenemy1();
    void upd();
    void towerpos();

private:
    QList<towerbase> towerbaselist;
    QList<tower*> towerlist;
    QList<enemy*> enemylist;
signals:

};

#endif // NEXTWINDOW_H
