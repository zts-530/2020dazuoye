#ifndef TOWER_H
#define TOWER_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include <QTimer>
#include "enemy.h"
class tower : public QObject
{
    Q_OBJECT
public:
    tower(QPoint point,QString pix);
    void draw(QPainter * painter);



private:
    QPoint _point;
    QPixmap pixmap;
    double _attackrange;
    double _firepower;
    double _firerate;




signals:

};

#endif // TOWER_H
