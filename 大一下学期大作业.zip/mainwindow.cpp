#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include "nextwindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    this->setFixedSize(1000,700);
    ui->setupUi(this);

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/color.mp3"));
    player->setVolume(30);
    player->play();


    QPushButton * b = new QPushButton(this);
    b->setFixedSize(100,50);
    b->setStyleSheet("QPushButton{color:white;background:black;border: 3px groove gray;border-radius:8px;border-style:outset}"
                     "QPushButton:hover{background-color:white; color: black;}"
                     "QPushButton:pressed{background-color:rgb(85, 170, 255); border-style:inset;}");
    b->setText("play");
    b->move(725,480);
    nextwindow * n = new nextwindow;
    connect(b,&QPushButton::clicked,this,[=](){
        this->close();
        n->show();
    });

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/zhujiemian.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

}
