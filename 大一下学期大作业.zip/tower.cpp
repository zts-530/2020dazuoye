#include "tower.h"
#include <QPoint>
#include <QPixmap>
#include <QPainter>
tower::tower(QPoint point,QString pix):QObject(0),pixmap(pix){
    _point=point;
    _attackrange=360;
    _firepower=20;
    _firerate=500;

}

void tower::draw(QPainter * painter){
    painter->drawPixmap(_point.rx(),_point.ry(),60,140,pixmap);
    painter->save();
    painter->setPen(Qt::blue);
    painter->drawEllipse(_point.rx()-110,_point.ry()-40, _attackrange, _attackrange);
    painter->restore();

}
