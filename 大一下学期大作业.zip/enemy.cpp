#include "enemy.h"

enemy::enemy(QString pix,QPoint p):QObject(0),pixmap(pix){
    this->p=p;
    hp=50;
    curhp=50;
};

void enemy::drawenemy(QPainter *painter){
    painter->drawPixmap(p.rx(),p.ry(),60,60,pixmap);

    static const int Health_Bar_Width=50;
    painter->save();
    QPoint healthBarPoint = p - QPoint(0,15);
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarBackRect(healthBarPoint, QSize(Health_Bar_Width, 2));
    painter->drawRect(healthBarBackRect);
    painter->setBrush(Qt::green);
    QRect healthBarRect(healthBarPoint, QSize((double)curhp/hp * Health_Bar_Width, 2));
    painter->drawRect(healthBarRect);
    painter->restore();
}
QPoint enemy::getpoint(){
    return this->p;
}
void enemy::setpoint(QPoint poi){
    this->p=poi;
}
void enemy::move(){
    QPropertyAnimation *animation = new QPropertyAnimation(this, "p");
    animation->setDuration(20000);
    animation->setStartValue(QPoint(1000,360));
    animation->setEndValue(QPoint(5,360));
    animation->start();
}
